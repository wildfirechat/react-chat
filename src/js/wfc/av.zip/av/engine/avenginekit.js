/*
 * Copyright (c) 2020 WildFireChat. All rights reserved.
 */

export class WfcAVEngineKit {
    sessionCallback;

    /**
     * 音视频window显示的时候调用
     */
    setup() {
    }
}
